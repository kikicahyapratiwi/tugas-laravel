<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('peminjaman', function (Blueprint $table) {
            $table->id();
            $table->string('id_buku')->nullable();
            $table->string('id_anggota');
            $table->string('id_petugas');
            $table->foreign('id_petugas')->references('username')->on('petugas');
            $table->string('tanggal_pinjam');
            $table->text('tanggal_kembali');
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('peminjaman');
    }
};
